/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>
#include <stdlib.h>
int main(void)
{
FILE *fptr; 
char ch;
int count=0;
fptr=fopen("welcome.txt","r");
if (fptr!=NULL)
{
while ((ch=getc(fptr)) != EOF)
{printf("%c", ch);
count++;
}
fclose(fptr);
printf("\n總共有%d個字元\n", count);
}
else
printf("檔案開啟失敗！！\n");
system("pause");
return 0;
}
