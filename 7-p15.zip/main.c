/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include <stdlib.h>
int main(void)
{
FILE *fptr1, *fptr2;
char ch;
fptr1=fopen( "welcome. txt","r");
fptr2=fopen( "output. txt", "w");
if ((fptr1!=NULL) &&(fptr2!=NULL))
{
while ((ch=getc( fptr1))!= EOF)
putc(ch, fptr2);
fclose(fptr1);
fclose(fptr2);
printf("檔案拷貝完成!!\n");
}
else
printf("檔案開啟失敗!!\n");
system("pause");
return 0;
}
